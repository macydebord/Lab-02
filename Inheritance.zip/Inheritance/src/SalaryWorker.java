public class SalaryWorker extends Worker
{
    private double annualSalary;

    public SalaryWorker(String id, String firstName, String lastName, String title, int YOB, double hourlyPayRate, double annualSalary)
    {
        super(id, firstName, lastName, title, YOB, hourlyPayRate);
        this.annualSalary = annualSalary;
    }

    @Override
    public double calculateWeeklyPay(double hoursWorked)
    {
        return annualSalary / 52.0;
    }

    //displayWeeklyPay needs to be overridden as well
    @Override
    public String displayWeeklyPay(double hoursWorked)
    {
        double weeklyPay = calculateWeeklyPay(hoursWorked);
        return String.format("Weekly pay (A fraction of the annual salary): " + weeklyPay + "\n" +
                "Annual Salary: " + annualSalary);
    }
}
