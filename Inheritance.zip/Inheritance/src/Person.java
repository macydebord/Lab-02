import java.util.Calendar;

public class Person
{
    private String id;
    private String firstName;
    private String lastName;
    private String title;
    private int YOB;

    public Person(String id, String firstName, String lastName, String title, int YOB)
    {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.title = title;
        this.YOB = YOB;
    }

    public String getId()
    {
        return id;
    }

    public void setId(String id)
    {
        this.id = id;
    }

    public String getFirstName()
    {
        return firstName;
    }

    public void setFirstName(String firstName)
    {
        this.firstName = firstName;
    }

    public String getLastName()
    {
        return lastName;
    }

    public void setLastName(String lastName)
    {
        this.lastName = lastName;
    }

    public String getTitle()
    {
        return title;
    }

    public void setTitle(String title)
    {
        this.title = title;
    }

    public int getYOB()
    {
        return YOB;
    }

    public void setYOB(int YOB)
    {
        this.YOB = YOB;
    }

    public String fullName ()
    {
        return this.firstName + " " + this.lastName;
    }

    public String formalName()
    {
        return this.title + " " + this.firstName + " " + this.lastName;
    }

    public String getAge() {
        return getAge(Calendar.getInstance().get(Calendar.YEAR));
    }

    public String getAge(int year)
    {
        if (year < YOB || year > Calendar.getInstance().get(Calendar.YEAR))
        {
            return ("Invalid year entered");
        }
        int age = year - YOB;
        return String.valueOf(age);
    }
}