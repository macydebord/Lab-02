public class SalaryWorkerTest
{
    public static void main(String[] args)
    {
        // create a test subject (hourly pay is 0 because annual salary is used to calculate pay)
        SalaryWorker salaryWorker = new SalaryWorker("000001", "Macy", "Debord", "Ms.", 2002, 0, 65000);

        double hoursWorked = 0;
        System.out.println(salaryWorker.displayWeeklyPay(hoursWorked));
    }
}
