import java.util.ArrayList;

public class InheritanceDemo
{
    public static void main(String[] args)
    {
        ArrayList<Worker> workersList = new ArrayList<>();

        // create workers
        Worker worker1 = new Worker("000001", "Macy", "Debord", "Ms.", 2002, 15.0);
        Worker worker2 = new Worker("000002", "Taylor", "Swift", "Ms.", 1989, 18.0);
        Worker worker3 = new Worker("000003", "Harry", "Styles", "Mr.", 1994, 20.0);

        workersList.add(worker1);
        workersList.add(worker2);
        workersList.add(worker3);

        // create salary workers
        SalaryWorker salaryWorker1 = new SalaryWorker("000004", "Phoebe", "Bridgers", "Ms.", 1998, 0, 60000);
        SalaryWorker salaryWorker2 = new SalaryWorker("000005", "Julien", "Baker", "Ms.", 1995, 0, 75000);
        SalaryWorker salaryWorker3 = new SalaryWorker("000006", "Lucy", "Dacus", "Ms.", 1990, 0, 90000);

        workersList.add(salaryWorker1);
        workersList.add(salaryWorker2);
        workersList.add(salaryWorker3);

        // loop to simulate weekly pay periods
        for (int week = 1; week <= 3; week++)
        {
            System.out.println("Week " + week + " Payroll:");

            // header
            System.out.printf("%-10s%-18s%-15s%n", "ID", "Name", "Weekly Pay");

            for (Worker worker : workersList)
            {
                double weeklyPay;

                if (week == 2)
                {
                    // for week 2: 50 hours
                    weeklyPay = worker.calculateWeeklyPay(50);
                } else
                {
                    // for weeks 1 and 3: 40 hours
                    weeklyPay = worker.calculateWeeklyPay(40);
                }

                System.out.printf("%-10s%-18s%-15.2f%n", worker.getId(), worker.fullName(), weeklyPay);
            }
            System.out.println();
        }
    }
}
