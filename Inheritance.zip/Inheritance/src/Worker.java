public class Worker extends Person
{
    private double hourlyPayRate;

    public Worker(String id, String firstName, String lastName, String title, int YOB, double hourlyPayRate)
    {
        super(id, firstName, lastName, title, YOB);
        this.hourlyPayRate = hourlyPayRate;
    }

    public double calculateWeeklyPay(double hoursWorked)
    {
        double hourlyRate = 0;
        double timeAndAHalfRate = 0;

        //if hours worked are less than 40 the pay rate would be normal
        if (hoursWorked <= 40)
        {
            hourlyRate = hoursWorked * hourlyPayRate;
        } else {
            //if over 40 hours they get overtime pay
            hourlyRate = 40 * hourlyPayRate;
            timeAndAHalfRate = (hoursWorked - 40) * 1.5 * hourlyPayRate;
        }

        return hourlyRate + timeAndAHalfRate;
    }

    public String displayWeeklyPay(double hoursWorked)
    {
        double regularPay = 0;
        double overtimePay = 0;

        if (hoursWorked <= 40)
        {
            regularPay = hoursWorked * hourlyPayRate;
        } else
        {
            regularPay = 40 * hourlyPayRate;
            overtimePay = (hoursWorked - 40) * 1.5 * hourlyPayRate;
        }

        double totalPay = regularPay + overtimePay;

        return String.format("Regular pay: " + regularPay + " \n" +
                "Overtime pay: " + overtimePay + " \n" +
                "Total pay: " + totalPay);
    }
}

