public class WorkerTest
{
    public static void main(String[] args)
    {
        //make a test subject
        Worker worker = new Worker("000001", "Macy", "Debord", "Ms.", 2002, 15.00);

        //testing under 40 hours (regular pay) and over 40 hours (overtime pay)
        double hoursWorked1 = 35;
        double hoursWorked2 = 45;

        double weeklyPay1 = worker.calculateWeeklyPay(hoursWorked1);
        double weeklyPay2 = worker.calculateWeeklyPay(hoursWorked2);

        System.out.println("\nTest 1:");
        System.out.println("Hours Worked: " + hoursWorked1);
        System.out.println("Total Weekly Pay: $" + weeklyPay1);

        System.out.println("\nTest 2:");
        System.out.println("Hours Worked: " + hoursWorked2);
        System.out.println("Total Weekly Pay: $" + weeklyPay2);
    }
}


